//url server

var url_server = 'http://103.113.81.38:5566/geoserver/test.tmtgis.vn/';

var urls_source = `${url_server}ows`;