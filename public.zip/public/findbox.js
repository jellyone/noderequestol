// const geolocation = new Geolocation({
//     // enableHighAccuracy must be set to true to have the heading value.
//     trackingOptions: {
//       enableHighAccuracy: true,
//     },
//     projection: view.getProjection(),
//   });
// const iconFeature = new ol.Feature({
//     geometry: new ol.geom.Point([0, 0]),
//     name: 'Null Island',
//     population: 4000,
//     rainfall: 500,
//   });


// const iconStyle = new ol.style.Style({
//     image: new ol.style.Icon({
//       anchor: [0.5, 46],
//       anchorXUnits: 'fraction',
//       anchorYUnits: 'pixels',
//       src: 'icon/icon.png',
//     }),
//   });

// iconFeature.setStyle(iconStyle);

// const vectorSource = new ol.source.Vector({
//         features: [iconFeature],
// });
var source_vector = new ol.source.Vector({wrapX: false});
var point = new ol.layer.Vector({
    source: source_vector,
});
let draw; 
// global so we can remove it later
function addInteraction() {
        draw = new ol.interaction.Draw({
        source: source_vector,
        type: 'MultiPoint',
        });
        map.addInteraction(draw);
        };


// var modify = new ol.interaction.Modify({
//     hitDetection: point,
//     source: vectorSource,

// })

